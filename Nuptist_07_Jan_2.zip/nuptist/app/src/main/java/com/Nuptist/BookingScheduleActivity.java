package com.Nuptist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class BookingScheduleActivity extends AppCompatActivity {
    TextView to_details;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_schedule);

        to_details = findViewById(R.id.to_details);


        to_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(BookingScheduleActivity.this,DetailsActivity.class);
                startActivity(intent);
            }
        });
    }
}