package com.Nuptist.VendorPackages.Bids.OffersBid;

import static com.Nuptist.RetrofitApis.BaseUrls.IMAGE_URL;

import android.app.DatePickerDialog;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.Nuptist.AddOnceNew.FinalAddonsNewModel;
import com.Nuptist.R;
import com.Nuptist.RetrofitApis.BidInterface;
import com.deishelon.roundedbottomsheet.RoundedBottomSheetDialog;
import com.squareup.picasso.Picasso;

import java.util.Calendar;
import java.util.List;

import soup.neumorphism.NeumorphCardView;

public class VendorOfferAdpater2 extends RecyclerView.Adapter<VendorOfferAdpater2.ViewHolder>{

    Context context ;
    List<FinalAddonsNewModel.FinalAddOnsData.ProductOfferDetailsId> model ;
    List<FinalAddonsNewModel.FinalAddOnsData.ServiceOfferDetailsId> model2 ;
    BidInterface bidInterface ;

    public VendorOfferAdpater2(Context context, List<FinalAddonsNewModel.FinalAddOnsData.ProductOfferDetailsId> model, List<FinalAddonsNewModel.FinalAddOnsData.ServiceOfferDetailsId> model2,BidInterface bidInterface ) {
        this.context = context;
        this.model = model;
        this.model2 = model2;
        this.bidInterface = bidInterface ;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.add_once_new_layout,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        try {

         if(model.size() != 0 ) {
             if (position < model.size()) {
                 FinalAddonsNewModel.FinalAddOnsData.ProductOfferDetailsId.Data__4 data = model.get(position).getData();
                 holder.title.setText(data.getProductName());
                 holder.price.setText("Rs. "+data.getBidMax()+" - "+data.getBidMin());

                 holder.bid_count.setText(data.getCount());
                 holder.bid_noe.setOnClickListener(view -> showDialog2(data.getId(), holder.getAbsoluteAdapterPosition()));
                 try {
                     if(data.getVender_status().equalsIgnoreCase("1")){
                         holder.bid_noe_inactive.setVisibility(View.VISIBLE);
                         holder.bid_noe.setVisibility(View.GONE);
                     }else {
                         holder.bid_noe_inactive.setVisibility(View.GONE);
                         holder.bid_noe.setVisibility(View.VISIBLE);
                     }
                 } catch (Exception e) {
                     e.printStackTrace();
                 }

                 try {
                     Picasso.get().load(IMAGE_URL+data.getImage()).into(holder.image);
                     Log.e("TAG", "onBindViewHolder() called with: Image Url = "+ IMAGE_URL+"  Image Path "+data.getImage());
                 } catch (Exception e) {
                     e.printStackTrace();
                     Log.e("TAG", "onBindViewHolder() called with: Image error "+e.getLocalizedMessage());

                 }


             }

            } else {


             if(model2.size() != 0){
                 int pos = position - model.size();

                 FinalAddonsNewModel.FinalAddOnsData.ServiceOfferDetailsId.Data__3  data = model2.get(pos).getData();
                 holder.title.setText(data.getName());
                 holder.price.setText("Rs. "+data.getBidMin()+" - "+data.getBidMax());

                 holder.bid_count.setText(data.getCount());

                 holder.bid_noe.setOnClickListener(view -> showDialog(data.getId(),pos));
                 try {
                     if(data.getVender_status().equalsIgnoreCase("1")){
                         holder.bid_noe_inactive.setVisibility(View.VISIBLE);
                         holder.bid_noe.setVisibility(View.GONE);
                     }else {
                         holder.bid_noe_inactive.setVisibility(View.GONE);
                         holder.bid_noe.setVisibility(View.VISIBLE);
                     }
                 } catch (Exception e) {
                     e.printStackTrace();
                 }


                 try {
                     Picasso.get().load(IMAGE_URL+data.getImage()).into(holder.image);
                     Log.e("TAG", "onBindViewHolder() called with: Image Url = "+ IMAGE_URL+"  Image Path "+data.getImage());
                 } catch (Exception e) {
                     e.printStackTrace();
                     Log.e("TAG", "onBindViewHolder() called with: Image error "+e.getLocalizedMessage());

                 }


             }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }



    }


    private void showDialog(String id, int holder) {

        RoundedBottomSheetDialog mBottomSheetDialog = new RoundedBottomSheetDialog(context);
        View sheetView = mBottomSheetDialog.getLayoutInflater().inflate(R.layout.add_bid_layout, null);

        mBottomSheetDialog.setContentView(sheetView);

        TextView update_dob = mBottomSheetDialog.findViewById(R.id.update_dob);
        EditText maximum_amoint = mBottomSheetDialog.findViewById(R.id.maximum_amoint);
        EditText minimum_amount = mBottomSheetDialog.findViewById(R.id.minimum_amount);
        NeumorphCardView add_bid_btn = mBottomSheetDialog.findViewById(R.id.add_bid_btn);
        LinearLayout parent_layout = mBottomSheetDialog.findViewById(R.id.parent_layout);


        parent_layout.setOnClickListener(view -> mBottomSheetDialog.dismiss());

        update_dob.setOnClickListener(view -> {
            selectDate(update_dob);
        });

        add_bid_btn.setOnClickListener(view -> {
            if(maximum_amoint.getText().toString().equalsIgnoreCase(""))
                maximum_amoint.setError("Enter Amount");
            else {

                bidInterface.addOfferBid(minimum_amount.getText().toString(),maximum_amoint.getText().toString(),"", id,id);
                notifyItemRemoved(holder);
                notifyItemRangeChanged(0,model2.size()-1);
                model2.remove(holder);
            }

            mBottomSheetDialog.dismiss();
        });

//      mBottomSheetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.ANSPARENT));
        mBottomSheetDialog.setContentView(sheetView);
        mBottomSheetDialog.show();

    }

    private void showDialog2(String id, int holder) {

        RoundedBottomSheetDialog mBottomSheetDialog = new RoundedBottomSheetDialog(context);
        View sheetView = mBottomSheetDialog.getLayoutInflater().inflate(R.layout.add_bid_layout, null);

        mBottomSheetDialog.setContentView(sheetView);

        TextView update_dob = mBottomSheetDialog.findViewById(R.id.update_dob);
        EditText maximum_amoint = mBottomSheetDialog.findViewById(R.id.maximum_amoint);
        EditText minimum_amount = mBottomSheetDialog.findViewById(R.id.minimum_amount);
        NeumorphCardView add_bid_btn = mBottomSheetDialog.findViewById(R.id.add_bid_btn);
        LinearLayout parent_layout = mBottomSheetDialog.findViewById(R.id.parent_layout);


        parent_layout.setOnClickListener(view -> mBottomSheetDialog.dismiss());

        update_dob.setOnClickListener(view -> {
            selectDate(update_dob);
        });

        add_bid_btn.setOnClickListener(view -> {
            if(maximum_amoint.getText().toString().equalsIgnoreCase(""))
                maximum_amoint.setError("Enter Amount");
            else {
                bidInterface.addOfferBid2(minimum_amount.getText().toString(),maximum_amoint.getText().toString(),"", id,id);
                notifyItemRemoved(holder);
                notifyItemRangeChanged(0,model.size()-1);
                model.remove(holder);
            }

            mBottomSheetDialog.dismiss();
        });

//      mBottomSheetDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.ANSPARENT));
        mBottomSheetDialog.setContentView(sheetView);
        mBottomSheetDialog.show();

    }


    private void selectDate(TextView DateBtn) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog datePickerDialog = new DatePickerDialog(context, (datePicker, year1, month1, day1) -> {
            String date = day1 + " /" + getMonthName((month1 + 1)) + "/ " +
                    "/" + year1;
            DateBtn.setText(date);
        }, year, month, day);
        datePickerDialog.show();
    }

    public String getMonthName(int month) {

        String monthString;
        switch (month) {
            case 1:
                monthString = "Jan";
                break;
            case 2:
                monthString = "Feb";
                break;
            case 3:
                monthString = "Mar";
                break;
            case 4:
                monthString = "Apr";
                break;
            case 5:
                monthString = "May";
                break;
            case 6:
                monthString = "Jun";
                break;
            case 7:
                monthString = "Jul";
                break;
            case 8:
                monthString = "Aug";
                break;
            case 9:
                monthString = "Sep";
                break;
            case 10:
                monthString = "Oct";
                break;
            case 11:
                monthString = "Nov";
                break;
            case 12:
                monthString = "Dec";
                break;
            default:
                monthString = "Inv month";
                break;
        }
        System.out.println(monthString);

        return monthString;
    }

    @Override
    public int getItemCount() {
        return model.size()+model2.size();
    }


    public  class  ViewHolder extends RecyclerView.ViewHolder{
        TextView title , price ,bid_count ;
        ImageView image ;
        LinearLayout bid_noe ,bid_noe_inactive;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            image = itemView.findViewById(R.id.add_once_image);
            title = itemView.findViewById(R.id.add_once_title);
            price = itemView.findViewById(R.id.add_once_price);
            bid_noe = itemView.findViewById(R.id.bid_noe);
            bid_count = itemView.findViewById(R.id.bid_count);
            bid_noe_inactive = itemView.findViewById(R.id.bid_noe_inactive);
        }
    }


}
