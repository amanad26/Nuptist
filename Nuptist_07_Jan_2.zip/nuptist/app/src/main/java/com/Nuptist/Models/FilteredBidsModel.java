package com.Nuptist.Models;

public class FilteredBidsModel {


}
