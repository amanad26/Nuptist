package com.Nuptist.adpaters;

import static com.Nuptist.RetrofitApis.BaseUrls.IMAGE_URL;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.Nuptist.AddOnceNew.FilterdFinalAddonsModel;
import com.Nuptist.AddOnceNew.FinalAddonsNewModel;
import com.Nuptist.Models.AddOncesModelNew;
import com.Nuptist.Models.BookingModels.BookingAddOnceModel;
import com.Nuptist.Models.FinalAdOns;
import com.Nuptist.PhotographyOfferActivity;
import com.Nuptist.R;
import com.Nuptist.databinding.AddOnceLayoutBinding;
import com.Nuptist.databinding.OfferAddonceLayoutBinding;
import com.squareup.picasso.Picasso;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AddOnsAdapterNew2 extends RecyclerView.Adapter<AddOnsAdapterNew2.ViewHolder>{

    Context context ;

    List<FinalAddonsNewModel.FinalAddOnsData.ProductId> model ;
    List<FinalAddonsNewModel.FinalAddOnsData.ServiceId> model2 ;
    public static  List<BookingAddOnceModel> addOnceModels = new ArrayList<>();
    String package_id ;

    public  static  String vendor_price = "" ;
      String   type = "";

    public AddOnsAdapterNew2(Context context, List<FinalAddonsNewModel.FinalAddOnsData.ProductId> model, List<FinalAddonsNewModel.FinalAddOnsData.ServiceId> model2, String pid ) {
        this.context = context;
        this.model = model;
        this.model2 = model2;
        this.package_id = pid ;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       return  new ViewHolder(LayoutInflater.from(context).inflate(R.layout.add_once_layout,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {


        try {
            if (position < model.size()) {
                FinalAddonsNewModel.FinalAddOnsData.ProductId.Data__2 data = model.get(position).getData();
                holder.binding.addOnceTitle.setText(data.getProductName());


                try {
                    if(data.getRecommendedPrice().equalsIgnoreCase("")){
                        holder.binding.addOncePrice.setText("Rs. 0");
                    }else {
                        holder.binding.addOncePrice.setText("Rs. "+data.getRecommendedPrice());
                    }
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }


                try {
                    Picasso.get().load(IMAGE_URL+data.getImage()).into(holder.binding.addOnceImage);
                } catch (Exception e) {
                    e.printStackTrace();
                }


                if(addOnceModels.size() != 0){
                    for(int i = 0 ; i<addOnceModels.size() ; i++){
                        Log.e("TAG", "onBindViewHolder() service  id = [" + addOnceModels.get(i).getService_id() + "], data.getId() = [" + data.getId() + "]");
                        if(addOnceModels.get(i).getProduct_id().equalsIgnoreCase(data.getId())){
                            holder.binding.addBtn.setVisibility(View.GONE);
                            holder.binding.cancleBtn.setVisibility(View.VISIBLE);
                        }

                    }

                }



            holder.binding.cancleBtn.setOnClickListener(view -> {
                holder.binding.addBtn.setVisibility(View.VISIBLE);
                holder.binding.cancleBtn.setVisibility(View.GONE);
                for(int i = 0 ;i <addOnceModels.size(); i++){
                    if(addOnceModels.get(i).getProduct_id().equalsIgnoreCase(data.getId())) {
                        addOnceModels.remove(i);
                    }
                }
                Log.e("TAG", "onClick() called with: Remove Add Once = [" + addOnceModels.toString() + "]");
            });


            holder.binding.cardview.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    type = "product";

                    if (data.getCount().equalsIgnoreCase("0")) {

                        holder.binding.addBtn.setVisibility(View.GONE);
                        holder.binding.cancleBtn.setVisibility(View.VISIBLE);

                        if(!data.isIsselected()){
                            addOnceModels.add(new BookingAddOnceModel(data.getId()
                                    ,data.getProductName()
                                    ,data.getRecommendedPrice()
                                    ,data.getRecommendedPrice()
                                    ,data.getId()
                                    ,"0"
                                    ,"0"
                                    ,""
                            ));
                            data.setIsselected(true);
                        }



                        Log.e("TAG", "onClick() called with: Remove Add Once = [" + addOnceModels.toString() + "]");
                    } else {
                        context.startActivity(new Intent(context, PhotographyOfferActivity.class)
                                .putExtra("addon_product_id", data.getId())
                                .putExtra("name", data.getProductName())
                                .putExtra("addon_product_data", (Serializable) data)
                                .putExtra("p_id", package_id)
                        );
                    }


                }
            });


            } else {
                int pos = position - model.size();

                FinalAddonsNewModel.FinalAddOnsData.ServiceId.Data__1  data = model2.get(pos).getData();
                holder.binding.addOnceTitle.setText(data.getName());


            try {

                if(data.getRecommendedPrice().equalsIgnoreCase("")){
                    holder.binding.addOncePrice.setText("Rs. 0");
                }else {
                    holder.binding.addOncePrice.setText("Rs. "+data.getRecommendedPrice());
                }
                } catch (NumberFormatException e) {
                e.printStackTrace();
             }


                if(addOnceModels.size() != 0){

                    for(int i = 0 ; i<addOnceModels.size() ; i++){
                        Log.e("TAG", "onBindViewHolder() service  id = [" + addOnceModels.get(i).getService_id() + "], data.getId() = [" + data.getId() + "]");
                        if(addOnceModels.get(i).getService_id().equalsIgnoreCase(data.getId())){
                            holder.binding.addBtn.setVisibility(View.GONE);
                            holder.binding.cancleBtn.setVisibility(View.VISIBLE);
                        }

                    }

                }



                try {
                    Picasso.get().load(IMAGE_URL+data.getImage()).into(holder.binding.addOnceImage);
                } catch (Exception e) {
                    e.printStackTrace();
                }


                holder.binding.cancleBtn.setOnClickListener(view -> {
                    holder.binding.addBtn.setVisibility(View.VISIBLE);
                    holder.binding.cancleBtn.setVisibility(View.GONE);
                    for(int i = 0 ; i <addOnceModels.size(); i++){
                        if(addOnceModels.get(i).getService_id().equalsIgnoreCase(data.getId())) {
                            addOnceModels.remove(i);
                        }
                    }
                    Log.e("TAG", "onClick() called with: Remove Add Once = [" + addOnceModels.toString() + "]");
                });


                holder.binding.cardview.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if (data.getCount().equalsIgnoreCase("0")) {
                            holder.binding.addBtn.setVisibility(View.GONE);
                            holder.binding.cancleBtn.setVisibility(View.VISIBLE);



                            if(!data.isIsselected()){
                                addOnceModels.add(new BookingAddOnceModel(data.getId()
                                        ,data.getName()
                                        ,data.getRecommendedPrice()
                                        ,data.getRecommendedPrice()
                                        ,"0"
                                        ,data.getId()
                                        ,"0"
                                        ,""
                                ));
                                data.setIsselected(true);
                            }

                            Log.e("TAG", "onClick() called with: Remove Add Once = [" + addOnceModels.toString() + "]");

                        } else {
                            type = "service";
                            context.startActivity(new Intent(context, PhotographyOfferActivity.class)
                                    .putExtra("addon_service_id", data.getId())
                                    .putExtra("addon_service_data", (Serializable) data)
                                    .putExtra("name", data.getName())
                                    .putExtra("p_id", package_id)
                            );
                        }


                    }
                });


            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        return model.size()+model2.size();
    }

    public  class  ViewHolder extends RecyclerView.ViewHolder{
        AddOnceLayoutBinding binding ;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = AddOnceLayoutBinding.bind(itemView);
        }
    }
}
