package com.Nuptist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class AddOfferSearchActivity extends AppCompatActivity {

    TextView add_offer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_offer_search);
        add_offer = findViewById(R.id.add_offer);

        add_offer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AddOfferSearchActivity.this,CreatPackageAddOfferActivity.class);
                startActivity(intent);
            }
        });
    }
}