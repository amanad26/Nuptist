package com.Nuptist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.content.res.AppCompatResources;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.Nuptist.databinding.ActivityCreateOfferServiceBinding;

public class CreateOfferServiceActivity extends AppCompatActivity {

    ImageView back;

    ActivityCreateOfferServiceBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCreateOfferServiceBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        binding.textServiceLabel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.llServiceBody.setVisibility(View.VISIBLE);
                binding.llProductBody.setVisibility(View.GONE);

                binding.textServiceLabel.setTextColor(getColor(R.color.white));
                binding.textProductLabel.setTextColor(getColor(R.color.black));

                binding.textServiceLabel.setBackground(AppCompatResources.getDrawable(CreateOfferServiceActivity.this, R.drawable.cardview_responsive));
                binding.textProductLabel.setBackground(AppCompatResources.getDrawable(CreateOfferServiceActivity.this, R.drawable.white_back));

            }
        });
        binding.textProductLabel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                binding.llServiceBody.setVisibility(View.GONE);
                binding.llProductBody.setVisibility(View.VISIBLE);

                binding.textServiceLabel.setTextColor(getColor(R.color.black));
                binding.textProductLabel.setTextColor(getColor(R.color.white2));

                binding.textServiceLabel.setBackground(AppCompatResources.getDrawable(CreateOfferServiceActivity.this, R.drawable.white_back));
                binding.textProductLabel.setBackground(AppCompatResources.getDrawable(CreateOfferServiceActivity.this, R.drawable.cardview_responsive));

            }
        });
    }
}