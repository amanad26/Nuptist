package com.Nuptist.mainscreens;

import android.content.Intent;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;


import com.Nuptist.CreatePackageDetailsActivity;
import com.Nuptist.DetailsActivity;
import com.Nuptist.Models.GetPackageModel;
import com.Nuptist.R;
import com.Nuptist.RetrofitApis.ApiInterface;
import com.Nuptist.RetrofitApis.RetrofitClient;
import com.Nuptist.SearchPackageActivity;
import com.Nuptist.Session.Session;
import com.Nuptist.adpaters.PackageListAdapter;
import com.Nuptist.adpaters.PopularPackageAdapter;
import com.skydoves.elasticviews.ElasticCardView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeUserFragment extends Fragment {
    ElasticCardView  details;
    CardView AG_SErach;
    LinearLayout tochech;
    View root;
    LinearLayout no_data__linear ,all_data_linear  ;
    RecyclerView packge_recycler, polular_recycler;
    List<GetPackageModel.PackageData> packageData = new ArrayList<>();
    Session session ;
    TextView see_more_btn ,see_more_btn_2;
    SwipeRefreshLayout swipe_refresh ;


    public  HomeUserFragment(){}

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_home_user, container, false);
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

       // AG_details = root.findViewById(R.id.AG_details);
        AG_SErach = root.findViewById(R.id.AG_SErach);
       // details_pg = root.findViewById(R.id.details_pg);
        details = root.findViewById(R.id.details);
        tochech = root.findViewById(R.id.tochech);
        packge_recycler = root.findViewById(R.id.packge_recycler);
        polular_recycler = root.findViewById(R.id.polular_recycler);
        no_data__linear = root.findViewById(R.id.no_data__linear);
        all_data_linear = root.findViewById(R.id.all_data_linear);
        see_more_btn = root.findViewById(R.id.see_more_btn);
        see_more_btn_2 = root.findViewById(R.id.see_more_btn_2);
        swipe_refresh = root.findViewById(R.id.swipe_refresh);

        if (getContext() != null) {
            session = new Session( getContext());
        }

        getPackageByCity();


        see_more_btn.setOnClickListener(v -> startActivity(new Intent(getContext(), CreatePackageDetailsActivity.class)));
        see_more_btn_2.setOnClickListener(v -> startActivity(new Intent(getContext(), CreatePackageDetailsActivity.class)));


        tochech.setOnClickListener(view -> {
            Intent intent = new Intent(getContext(), DetailsActivity.class);
            startActivity(intent);
        });

        AG_SErach.setOnClickListener(view -> {
            Intent intent = new Intent(getActivity(), SearchPackageActivity.class);
            startActivity(intent);
        });

        swipe_refresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getPackageByCity();
            }
        });


        return root;

    }


    private void getPackageByCity() {

        ApiInterface apiInterface = RetrofitClient.getclient(getContext());

        apiInterface.getPackageByCity(session.getMycity()).enqueue(new Callback<GetPackageModel>() {
            @Override
            public void onResponse(@NonNull Call<GetPackageModel> call, @NonNull Response<GetPackageModel> response) {
                swipe_refresh.setRefreshing(false);
                try {

                    if (response.code() == 200) {
                        if (response.body() != null)
                            if (response.body().getResult().equalsIgnoreCase("true")) {

                                      packageData.clear();
                                      for (int i = 0; i < response.body().getData().size(); i++) {

                                        if (response.body().getData().get(i).getUsers_status().equalsIgnoreCase("1"))
                                              packageData.add(response.body().getData().get(i));
                                        }

                                    if(packageData.size() != 0){
                                        packge_recycler.setLayoutManager(new LinearLayoutManager(getContext()));
                                        packge_recycler.setAdapter(new PackageListAdapter(getContext(), packageData, response.body().getPath(), 10));

                                        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
                                        linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
                                        polular_recycler.setLayoutManager(linearLayoutManager);
                                        polular_recycler.setAdapter(new PopularPackageAdapter(getContext(), packageData, response.body().getPath()));
                                        no_data__linear.setVisibility(View.GONE);
                                        all_data_linear.setVisibility(View.VISIBLE);
                                    }else {
                                     //   no_data__linear.setVisibility(View.VISIBLE);
                                        Toast.makeText(getContext(), "No Data Found", Toast.LENGTH_SHORT).show();
                                    }

                            } else {
                               // no_data__linear.setVisibility(View.VISIBLE);
                                Toast.makeText(getContext(), "No Packages Found", Toast.LENGTH_SHORT).show();
                            }

                    }


                } catch (Exception e) {
                    e.getLocalizedMessage();
                }

            }

            @Override
            public void onFailure(@NonNull Call<GetPackageModel> call, @NonNull Throwable t) {
                Log.e("TAG", "onFailure() called with: call = [" + call + "], t = [" + t.getLocalizedMessage() + "]");
                swipe_refresh.setRefreshing(false);
                //  no_data__linear.setVisibility(View.VISIBLE);
            }
        });

    }


}
