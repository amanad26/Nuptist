package com.Nuptist;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class AddOnsSearchActivity extends AppCompatActivity {

    TextView add_ons;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_ons_search);
        add_ons = findViewById(R.id.add_ons);


        add_ons.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AddOnsSearchActivity.this,CreatePackageAddOnsActivity.class);
                startActivity(intent);
            }
        });
    }
}