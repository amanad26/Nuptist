package com.Nuptist;

public class RecylerAllBinding {
}
