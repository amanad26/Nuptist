package com.Nuptist.adpaters;

import static com.Nuptist.RetrofitApis.BaseUrls.USER_IMAGE_URL;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.Nuptist.MyBookings.MyBookingDetailsModel;
import com.Nuptist.R;
import com.Nuptist.databinding.BookedVendorLayoutBinding;
import com.squareup.picasso.Picasso;

import java.util.List;

public class BookedBidsVendorAdapter extends RecyclerView.Adapter<BookedBidsVendorAdapter.ViewHolder>{

    Context context ;
    List<MyBookingDetailsModel.MyBookingdata.BidsAddonce> model ;
    List<MyBookingDetailsModel.MyBookingdata.BidsOffer> model2 ;

    public BookedBidsVendorAdapter(Context context, List<MyBookingDetailsModel.MyBookingdata.BidsAddonce> model, List<MyBookingDetailsModel.MyBookingdata.BidsOffer> model2) {
        this.context = context;
        this.model = model;
        this.model2 = model2;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.booked_vendor_layout,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        try{

           if( position < model.size()){
               MyBookingDetailsModel.MyBookingdata.BidsAddonce data = model.get(position);
               holder.binding.notificationTitle.setText(data.getVenderName());
               holder.binding.notificationText.setText(data.getAddonceName());
               holder.binding.notificationTime.setText("Rs. "+data.getBidsPrice());
               Picasso.get().load(USER_IMAGE_URL+data.getVenderImage()).placeholder(R.drawable.loading).into(holder.binding.notificationImage);

           }else {
               int pos =    position - model2.size();

               MyBookingDetailsModel.MyBookingdata.BidsOffer data = model2.get(pos);
               holder.binding.notificationTitle.setText(data.getVenderName());
               holder.binding.notificationText.setText(data.getOfferName());
               holder.binding.notificationTime.setText("Rs. "+data.getBidsPrice());

               Picasso.get().load(USER_IMAGE_URL+data.getVenderImage()).placeholder(R.drawable.loading).into(holder.binding.notificationImage);

           }



        }catch (Exception e){
            e.getLocalizedMessage();
        }


    }

    @Override
    public int getItemCount() {
        return model.size()+model2.size();
    }

    public  class  ViewHolder extends RecyclerView.ViewHolder{
        BookedVendorLayoutBinding binding ;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = BookedVendorLayoutBinding.bind(itemView);
        }
    }
}
