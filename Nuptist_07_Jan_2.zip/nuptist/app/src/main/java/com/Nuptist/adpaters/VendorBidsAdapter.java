package com.Nuptist.adpaters;

import static com.Nuptist.RetrofitApis.BaseUrls.USER_IMAGE_URL;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.Nuptist.Models.VendorBidsModel;
import com.Nuptist.Models.VendorInterface;
import com.Nuptist.R;
import com.Nuptist.databinding.VendorBidsListLayoutBinding;
import com.squareup.picasso.Picasso;

import java.util.List;

public class VendorBidsAdapter extends RecyclerView.Adapter<VendorBidsAdapter.ViewHolder>{

    boolean islected = false;

    Context context ;
    int pos = -1 ;
    List<VendorBidsModel.VendorBidData> model;
    VendorInterface vendorInterface ;
    String vendor_name = "" , vendor_id  = "", vendor_price = "" ;

    public VendorBidsAdapter(Context context, List<VendorBidsModel.VendorBidData> model, VendorInterface vendorInterface ) {
        this.context = context;
        this.model = model;
        this.vendorInterface = vendorInterface ;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return  new ViewHolder(LayoutInflater.from(context).inflate(R.layout.vendor_bids_list_layout,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.binding.userName.setText(model.get(position).getUserName());
        holder.binding.userBidPrice.setText(model.get(position).getBidsPrice());

        Picasso.get().load(USER_IMAGE_URL+model.get(position).getUserImage()).into(holder.binding.userImage);
        Picasso.get().load(USER_IMAGE_URL+model.get(position).getCoverImage()).into(holder.binding.userCoverImage);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(pos == -1){
                    holder.binding.selectedImage.setVisibility(View.VISIBLE);
                    islected = true ;
                    pos = holder.getAbsoluteAdapterPosition() ;
                    vendor_name = model.get(holder.getAbsoluteAdapterPosition()).getUserName();
                    vendor_price = model.get(holder.getAbsoluteAdapterPosition()).getBidsPrice();
                    vendor_id = model.get(holder.getAbsoluteAdapterPosition()).getBidsId();
                    vendorInterface.getPrice(vendor_price,vendor_name,vendor_id);
                }else {

                    if(pos == holder.getAbsoluteAdapterPosition()){
                        holder.binding.selectedImage.setVisibility(View.GONE);
                        islected = false ;
                        pos =  -1 ;
                        vendor_id = "";
                        vendor_name = "";
                        vendor_price = "";
                    }
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return model.size();
    }

    public  class  ViewHolder extends RecyclerView.ViewHolder{

        VendorBidsListLayoutBinding binding ;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = VendorBidsListLayoutBinding.bind(itemView);
        }
    }
}
