package com.Nuptist;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;

public class CreatePackageActivity extends AppCompatActivity {

    EditText opn_calender;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_package);

        opn_calender = findViewById(R.id.opn_calender);


        opn_calender.setOnClickListener(view -> showdialog());
    }



    private void showdialog() {

        final Dialog dialog = new Dialog(CreatePackageActivity.this);
        dialog.setContentView(R.layout.calender_layout);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dialog.setCancelable(false);
        dialog.getWindow().getAttributes().windowAnimations = R.style.animation;


        ImageView set_date = (ImageView) dialog.findViewById(R.id.set_date);

        set_date.setOnClickListener(v -> dialog.dismiss());


        // show the exit dialog
        dialog.show();

    }

}