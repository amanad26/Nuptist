package com.Nuptist;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.Nuptist.databinding.FragmentAllSearchBinding;

public class AllSearchFragment extends Fragment {
  View root;
  RecyclerView recy_searchresult;
  FragmentAllSearchBinding binding ;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment

        binding = FragmentAllSearchBinding.inflate(getLayoutInflater());
       // root = inflater.inflate(R.layout.fragment_all_search, container, false);
       // recy_searchresult = root.findViewWithTag(R.id.recy_searchresult_2);



       return  binding.getRoot();
       ///return root;
    }
}