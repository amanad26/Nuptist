package com.Nuptist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class AddVenueSearchResultActivity extends AppCompatActivity {

    CardView add_venue,add_venue1,add_venue2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_venue_search_result);

        add_venue = findViewById(R.id.add_venue);
        add_venue1 = findViewById(R.id.add_venue1);
        add_venue2 = findViewById(R.id.add_venue2);


        add_venue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AddVenueSearchResultActivity.this,FinalVenueAddedActivity.class);

            }
        });



        add_venue1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AddVenueSearchResultActivity.this,FinalVenueAddedActivity.class);

            }
        });




        add_venue2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AddVenueSearchResultActivity.this,FinalVenueAddedActivity.class);

            }
        });
    }
}