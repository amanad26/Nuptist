package com.Nuptist;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class SearchResultListAdapter extends FragmentStateAdapter {


    public SearchResultListAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        if (position == 0)
            return new AllSearchFragment();
        else if (position == 1) return new LocalSearchFragment();
        else if (position == 2) return new ReceptionSearchFragment();
        else if (position == 3) return new Pre_WeedingFragment();
        else   return new RegularWeedingFragment();

    }

    @Override
    public int getItemCount() {
        return 5;
    }
}
