package com.Nuptist.mainscreens;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.Nuptist.DetailsActivity;
import com.Nuptist.Models.MyFavoritePackageModel;
import com.Nuptist.Models.ProgressDialog;
import com.Nuptist.R;
import com.Nuptist.RetrofitApis.ApiInterface;
import com.Nuptist.RetrofitApis.RetrofitClient;
import com.Nuptist.Session.Session;
import com.Nuptist.adpaters.MyFavoritePackageAdapter;
import com.skydoves.elasticviews.ElasticCardView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FavoriteFragment extends Fragment {

    View root;

    ElasticCardView to_details;
    RecyclerView my_fav_recycler ;
    Session session ;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        root = inflater.inflate(R.layout.fragment_favorite, container, false);

        if (getContext() != null)
        session = new Session(getContext());

        to_details = root.findViewById(R.id.to_details);
        my_fav_recycler = root.findViewById(R.id.my_fav_recycler);

        to_details.setOnClickListener(view -> {
            Intent intent = new Intent(getContext(), DetailsActivity.class);
            startActivity(intent);
        });


        getFavoriteList();

        return root;

    }

    private  void getFavoriteList(){
        ProgressDialog pd ;
        pd = new ProgressDialog(getContext());
        pd.show();



        ApiInterface apiInterface = RetrofitClient.getclient(getContext());

        String userid  ;
        if(session.getType().equalsIgnoreCase("Vendor")){
            userid =  session.getUserId_Vendor();
        }else {
            userid = session.getUserId();
        }


        apiInterface.favoriteList(userid).enqueue(new Callback<MyFavoritePackageModel>() {
            @Override
            public void onResponse(@NonNull Call<MyFavoritePackageModel> call, @NonNull Response<MyFavoritePackageModel> response) {

                pd.dismiss();
                try {

                    if(response.code() == 200)
                    if (response.body() != null) {
                        if(response.body().getResult().equalsIgnoreCase("true")){
                            my_fav_recycler.setLayoutManager(new LinearLayoutManager(getContext()));
                            my_fav_recycler.setAdapter(new MyFavoritePackageAdapter(getContext(),response.body().getData(),response.body().getPath()));

                            Log.e("TAG", "onResponse() called with: call = [" + call + "], response = [" + response + "]");
                        }else {
                            Toast.makeText(getContext(), "Data Not Found", Toast.LENGTH_SHORT).show();
                        }
                    }

                }catch (Exception e){
                    pd.dismiss();
                    e.getLocalizedMessage();
                }

            }

            @Override
            public void onFailure(@NonNull Call<MyFavoritePackageModel> call, @NonNull Throwable t) {
                pd.dismiss();
                Log.e("TAG", "onFailure() called with: call = [" + call + "], t = [" + t.getLocalizedMessage() + "]");
            }
        });


    }

}
