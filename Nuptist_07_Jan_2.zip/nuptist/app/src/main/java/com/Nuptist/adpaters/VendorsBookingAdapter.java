package com.Nuptist.adpaters;

import static com.Nuptist.FormatDate.formatDate;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.Nuptist.Models.MyBookingModel;
import com.Nuptist.R;
import com.Nuptist.databinding.MyBookingLayoutBinding;
import com.airbnb.lottie.animation.content.Content;

import java.util.List;

public class VendorsBookingAdapter extends RecyclerView.Adapter<VendorsBookingAdapter.ViewHolder>{

    Context context ;
    List<MyBookingModel.MyBookingData> model ;

    public VendorsBookingAdapter(Context context, List<MyBookingModel.MyBookingData> model) {
        this.context = context;
        this.model = model;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(context).inflate(R.layout.my_booking_layout,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        try {
            if(model.get(position).getPackage_name() != null)
                holder.binding.packageName.setText(model.get(position).getPackage_name());

            holder.binding.date.setText(formatDate(model.get(position).getStartDate()) + " to "+formatDate(model.get(position).getEndDate()));
            holder.binding.totalPrice.setText("Rs. "+model.get(position).getTotalAmount());

            if(model.get(position).getBookingStatus().equalsIgnoreCase("pending")){
                holder.binding.status.setText(model.get(position).getBookingStatus());
            }else if (model.get(position).getBookingStatus().equalsIgnoreCase("cancelled")){
                holder.binding.status.setTextColor(context.getResources().getColor(R.color.red));
                holder.binding.status.setText(model.get(position).getBookingStatus());
            }


           //// getPackageDetials(model.get(position).getPackageId(), holder);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        return model.size();
    }

    public  class  ViewHolder extends RecyclerView.ViewHolder{
        MyBookingLayoutBinding binding ;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = MyBookingLayoutBinding.bind(itemView);
        }
    }
}
