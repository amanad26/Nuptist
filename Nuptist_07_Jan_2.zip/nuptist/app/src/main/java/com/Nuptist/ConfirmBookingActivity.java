package com.Nuptist;

import static com.Nuptist.RetrofitApis.BaseUrls.IMAGE_URL;
import static com.Nuptist.adpaters.AddOnsAdapterNew2.addOnceModels;
import static com.Nuptist.adpaters.OfferAdapter2.offersModel;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.Nuptist.Models.BookingModels.BookingAddOnceModel;
import com.Nuptist.Models.BookingModels.BookingOffersModel;
import com.Nuptist.Models.LogOutModel;
import com.Nuptist.Models.PackageDetailsModel;
import com.Nuptist.Models.ProgressDialog;

import com.Nuptist.RetrofitApis.ApiInterface;
import com.Nuptist.RetrofitApis.RetrofitClient;
import com.Nuptist.Session.Session;
import com.Nuptist.databinding.ActivityConfirmBookingBinding;
import com.Nuptist.databinding.OfferAddonceLayoutBinding;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ConfirmBookingActivity extends AppCompatActivity {

    ActivityConfirmBookingBinding binding;

    String TAG = "ConfirmBookingActivity";
    String package_id, package_name, venue_price , finalPackagePrice, total_addons, total_offers, start_date, end_date, selectedOffers, selectedAddonce;

    Session session;
    ProgressDialog pd;
    boolean isaddonceseleced = false;
    boolean isofferseleced = false;

    String serviceaddonsId, productaddonsId, servieoffersId, productofferId , offer_id_vendor , addons_vendor;

    List<BookingOffersModel> offersModelNew  = new ArrayList<>();
    List<BookingAddOnceModel> addOnceModelsNew = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityConfirmBookingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        session = new Session(ConfirmBookingActivity.this);

        pd = new ProgressDialog(ConfirmBookingActivity.this);
        pd.show();

        try {
            package_id = getIntent().getStringExtra("package_id");
            total_addons = getIntent().getStringExtra("total_addons");
            total_offers = getIntent().getStringExtra("total_offers");
            start_date = getIntent().getStringExtra("start_date");
            end_date = getIntent().getStringExtra("end_date");
            selectedOffers = getIntent().getStringExtra("selectedOffers");
            selectedAddonce = getIntent().getStringExtra("selectedAddonce");
            selectedAddonce = getIntent().getStringExtra("selectedAddonce");
            finalPackagePrice = getIntent().getStringExtra("finalPackagePrice");
            serviceaddonsId = getIntent().getStringExtra("serviceaddonsId");
            productaddonsId = getIntent().getStringExtra("productaddonsId");
            servieoffersId = getIntent().getStringExtra("servieoffersId");
            productofferId = getIntent().getStringExtra("productofferId");
            venue_price = getIntent().getStringExtra("venue_price");
            offersModelNew = (List<BookingOffersModel>) getIntent().getSerializableExtra("offermodel");
            addOnceModelsNew = (List<BookingAddOnceModel>) getIntent().getSerializableExtra("addonsmodel");
            offer_id_vendor = getIntent().getStringExtra("offer_id_vendor");
            addons_vendor = getIntent().getStringExtra("addons_vendor");


            Log.e(TAG, "onCreate() called with: package_id = [" + package_id + "]");
            Log.e(TAG, "onCreate() called with: total_addons = [" + total_addons + "]");
            Log.e(TAG, "onCreate() called with: total_offers = [" + total_offers + "]");
            Log.e(TAG, "onCreate() called with: start_date = [" + start_date + "]");
            Log.e(TAG, "onCreate() called with: end_date = [" + end_date + "]");

            binding.tottalOffers.setText("(" + total_offers + ")");
            binding.tottalAddons.setText("(" + total_addons + ")");

            binding.dateId.setText("Your booking is ready and suitable for the specified date " + "(" + formatDate(start_date) + " To " + formatDate(end_date) + ")");

            binding.totalPrice.setText("Rs. " + finalPackagePrice);

            binding.venuePrice.setText("Rs. "+venue_price);

            binding.addonsRecler.setLayoutManager(new LinearLayoutManager(ConfirmBookingActivity.this));
            binding.addonsRecler.setAdapter(new OfferInnerAdapter(ConfirmBookingActivity.this, offersModelNew, addOnceModelsNew,1));

            binding.offerRecler.setLayoutManager(new LinearLayoutManager(ConfirmBookingActivity.this));
            binding.offerRecler.setAdapter(new OfferInnerAdapter(ConfirmBookingActivity.this, offersModelNew, addOnceModelsNew,0));


            binding.vewAddOnceRecy.setOnClickListener(v -> {
                if(binding.addonsRecler.getVisibility() == View.VISIBLE){
                    binding.addonsRecler.setVisibility(View.GONE);
                }else {
                    binding.addonsRecler.setVisibility(View.VISIBLE);
                }
            });

            binding.vewAddOnceRecy.setOnClickListener(v -> {
                if(binding.offerRecler.getVisibility() == View.VISIBLE){
                    binding.offerRecler.setVisibility(View.GONE);
                }else{
                    binding.offerRecler.setVisibility(View.VISIBLE);
                }
            });


            getPackageDetials(package_id);
        } catch (Exception e) {
            e.printStackTrace();
        }

        binding.icSelectdAddons.setOnClickListener(v -> {

            if (isaddonceseleced) {
                isaddonceseleced = false;
                binding.icSelectdAddons.setImageResource(R.drawable.ic_arrow_up);
                binding.addonsRecler.setVisibility(View.VISIBLE);
            } else {
                isaddonceseleced = true;
                binding.icSelectdAddons.setImageResource(R.drawable.ic_arrow_down);
                binding.addonsRecler.setVisibility(View.GONE);
            }

        });


        binding.icSelectdOffers.setOnClickListener(v -> {
            if (isofferseleced) {
                isofferseleced = false;
                binding.icSelectdOffers.setImageResource(R.drawable.ic_arrow_up);
                binding.offerRecler.setVisibility(View.VISIBLE);
            } else {
                isofferseleced = true;
                binding.icSelectdOffers.setImageResource(R.drawable.ic_arrow_down);
                binding.offerRecler.setVisibility(View.GONE);
            }
        });

        binding.bookingNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addData();
            }
        });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    private void addData() {

        pd.show();

        Random random = new Random();
        int transectionId = random.nextInt(1000000);


        if (serviceaddonsId.equalsIgnoreCase("")) {
            serviceaddonsId = "0,0";
        }

        if (servieoffersId.equalsIgnoreCase("")) {
            servieoffersId = "0,0";
        }
        if (productofferId.equalsIgnoreCase("")) {
            productofferId = "0,0";
        }

        if (productaddonsId.equalsIgnoreCase("")) {
            productaddonsId = "0,0";
        }

        if(addons_vendor.equalsIgnoreCase(""))
            addons_vendor = "0,0";

          if(offer_id_vendor.equalsIgnoreCase(""))
              offer_id_vendor = "0,0";


        ApiInterface apiInterface = RetrofitClient.getclient(ConfirmBookingActivity.this);

        apiInterface.addBookingDates(
                package_id,
                session.getUserId(),
                "1",
                String.valueOf(finalPackagePrice),
                start_date,
                end_date,
                String.valueOf(transectionId),
                "UPI",
                selectedOffers,
                selectedAddonce,
                package_name,
                serviceaddonsId,
                productaddonsId,
                servieoffersId,
                productofferId,
                addons_vendor,
                offer_id_vendor
        ).enqueue(new Callback<LogOutModel>() {
            @Override
            public void onResponse(@NonNull Call<LogOutModel> call, @NonNull Response<LogOutModel> response) {

                pd.dismiss();
                try {
                    if (response.code() == 200 && response.body() != null)
                        if (response.body().getResult().equalsIgnoreCase("true")) {
                            pd.dismiss();

                            addOnceModels.clear();
                            offersModel.clear();
                            Toast.makeText(ConfirmBookingActivity.this, "Booking Successful..", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(ConfirmBookingActivity.this, SucessActivity.class)
                                    .putExtra("text", "Booking successfully  please wait for Admin Approval"));
                            finish();

                        } else {


                            pd.dismiss();
                            Toast.makeText(ConfirmBookingActivity.this, "Booking Failed..", Toast.LENGTH_SHORT).show();
                        }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onFailure(@NonNull Call<LogOutModel> call, @NonNull Throwable t) {
                pd.dismiss();
                Log.e("TAG", "onFailure() called with: call = [" + call + "], t = [" + t.getLocalizedMessage() + "]");
            }
        });

    }


    private void getPackageDetials(String packageId) {

        ApiInterface apiInterface = RetrofitClient.getclient(ConfirmBookingActivity.this);

        apiInterface.getPackagesDetails(packageId, session.getUserId()).enqueue(new Callback<PackageDetailsModel>() {
            @Override
            public void onResponse(@NonNull Call<PackageDetailsModel> call, @NonNull Response<PackageDetailsModel> response) {
                pd.dismiss();
                try {

                    if (response.body() != null) {
                        if (response.body().getResult().equalsIgnoreCase("true")) {

                            binding.packagePeople.setText(response.body().getData().getVenue().get(0).getGuestCapycityMix() + " People");
                            binding.bigAndLux.setText(response.body().getData().getPackages().getPackageName());
                            binding.day.setText(response.body().getData().getPackages().getPrice());

                            package_name = response.body().getData().getPackages().getPackageName();

                            String res = response.body().getData().getPackages().getCity().substring(0, 1).toUpperCase() + response.body().getData().getPackages().getCity().substring(1);
                            binding.packageAddress.setText(res);

                            try {

                                if (String.valueOf(response.body().getData().getPackages().getI_liked()).equalsIgnoreCase("1"))
                                    binding.likedImage.setImageResource(R.drawable.ic_baseline_favorite_24);

                                Picasso.get().load(IMAGE_URL + response.body().getData().getPackages().getImage()).placeholder(R.drawable.ic_nature_svg).into(binding.packageImage);
                                binding.packageCreatedDate.setText(formatDate(response.body().getData().getPackages().getStartDate()));


                            } catch (Exception e) {
                                pd.dismiss();
                                e.getLocalizedMessage();
                                Log.e("TAG", "Start Date Error  = [" + e.getLocalizedMessage() + "]");
                            }

                        }
                    }

                } catch (Exception e) {
                    pd.dismiss();
                    Log.e("Date--------->", "onResponse() called with: Start Date = [" + call + "], response = [" + e.getLocalizedMessage() + "]");
                    e.getLocalizedMessage();
                }

            }

            @Override
            public void onFailure(@NonNull Call<PackageDetailsModel> call, @NonNull Throwable t) {
                pd.dismiss();
                Log.e("TAG", "onFailure() called with: call = [" + call + "], t = [" + t.getLocalizedMessage() + "]");

            }
        });


    }


    public String formatDate(String s) {
        //  s = "2022-10-21 08:08:18";

        String[] dateTime = s.split(" ");

        String dateS = dateTime[0];
//        String timeS = dateTime[1];
//
//        timeS = timeS.substring(0, 5);

        String[] datess = dateS.split("-");

        String year = datess[0];
        String month = datess[1];
        String day = datess[2];

        return day + " " + getMonthName(Integer.parseInt(month)) + " " + year + " ";
    }

    public String getMonthName(int month) {

        String monthString;
        switch (month) {
            case 1:
                monthString = "January";
                break;
            case 2:
                monthString = "February";
                break;
            case 3:
                monthString = "March";
                break;
            case 4:
                monthString = "April";
                break;
            case 5:
                monthString = "May";
                break;
            case 6:
                monthString = "June";
                break;
            case 7:
                monthString = "July";
                break;
            case 8:
                monthString = "August";
                break;
            case 9:
                monthString = "September";
                break;
            case 10:
                monthString = "October";
                break;
            case 11:
                monthString = "November";
                break;
            case 12:
                monthString = "December";
                break;
            default:
                monthString = "Invalid month";
                break;
        }
        System.out.println(monthString);

        return monthString;
    }

    public  class  OfferInnerAdapter extends RecyclerView.Adapter<OfferInnerAdapter.ViewHolder>{

        Context context ;
        List<BookingOffersModel> model ;
        List<BookingAddOnceModel> model2 ;
        int TYPE = 0 ;

        public OfferInnerAdapter(Context context, List<BookingOffersModel> model, List<BookingAddOnceModel> model2, int TYPE) {
            this.context = context;
            this.model = model;
            this.model2 = model2;
            this.TYPE = TYPE;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return  new ViewHolder(LayoutInflater.from(context).inflate(R.layout.offer_addonce_layout,parent,false));
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

            try {

                if(TYPE  == 0 ){
                    holder.binding.offerName.setText(model.get(position).getOfferName());
                    holder.binding.offerPrice.setText("Rs. "+model.get(position).getOfferPrice());
                    if(!model.get(position).getVendor_name().equalsIgnoreCase("")) {
                        holder.binding.offerVendorName.setText(model.get(position).getVendor_name());
                        holder.binding.offerVendorName.setVisibility(View.VISIBLE);
                    }

                }else {
                    holder.binding.offerName.setText(model2.get(position).getAddOnceName());
                    holder.binding.offerPrice.setText("Rs. "+model2.get(position).getAddOnceMaPrice());
                    if(!model2.get(position).getVendor_name().equalsIgnoreCase("")) {
                        holder.binding.offerVendorName.setText(model2.get(position).getVendor_name());
                        holder.binding.offerVendorName.setVisibility(View.VISIBLE);
                    }

                }

            }catch (Exception e){
                e.getLocalizedMessage();
            }


        }

        @Override
        public int getItemCount() {
           if (TYPE == 0 )return model.size();
           else return model2.size();
        }

        public class  ViewHolder extends RecyclerView.ViewHolder{
            OfferAddonceLayoutBinding binding ;
            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                binding = OfferAddonceLayoutBinding.bind(itemView);
            }
        }

    }
}

