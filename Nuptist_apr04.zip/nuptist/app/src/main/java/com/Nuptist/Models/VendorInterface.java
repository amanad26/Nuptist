package com.Nuptist.Models;

public interface VendorInterface {
    void getPrice(String price , String name , String vendor_id);

}
