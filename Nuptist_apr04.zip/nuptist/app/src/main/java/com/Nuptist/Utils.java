package com.Nuptist;

public class Utils {

    public  static  String OfferAddonsToast = "Select date before adding offers and addon's";
}
