package com.Nuptist.RetrofitApis;

public interface MapInterface {
    
    void getAddress(double lat, double lang , String address);
    
}
