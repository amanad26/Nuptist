package com.Nuptist.firebase.firebase;

public class NotiModel {
}
