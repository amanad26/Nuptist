package com.Nuptist.RetrofitApis;

public interface BookPackageInterface {

    void onDateChange();
    void onBooking();
}
