package com.Nuptist;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CreatePackageAddOnsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_package_add_ons);
    }
}