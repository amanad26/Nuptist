package com.Nuptist.RetrofitApis;

public interface PackageDetailsInterface {

    void onAddonsAdd();
    void onAddonsRemove();
    void onOfferAdd();
    void offerRemove();
    void onDateChange();
}
